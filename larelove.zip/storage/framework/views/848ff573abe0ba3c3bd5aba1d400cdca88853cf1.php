<div class="form-group">
    <input  name="title" type="text" class="form-control"  required value="<?php echo e(old('title') ?? $post->title ?? ''); ?>">
</div>
<div class="form-group">
    <textarea name="descr"   rows="10" class="form-control"> <?php echo e(old('descr') ?? $post->descr ?? ''); ?> </textarea>
</div>
<div class="form-group">
    <input type="file" name="img">
</div>
<?php /**PATH C:\xampp\htdocs\larelove\resources\views/posts/parts/form.blade.php ENDPATH**/ ?>