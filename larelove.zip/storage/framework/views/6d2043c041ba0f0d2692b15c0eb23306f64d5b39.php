    <?php $__env->startSection('content'); ?>

        <?php if(isset($_GET['search'])): ?>
            <?php if(count($posts)>0): ?>
                <h2>Результаты поиска <?=$_GET['search']?></h2>
                <p class="lead"> Всего найдено "<?php echo e(count($posts)); ?>" постов </p>
            <?php else: ?>
                <h2>По запросу "<?= htmlspecialchars($_GET['search'])?>" ничего не найдено</h2>
                <a href="<?php echo e(route('post.index')); ?>" class="btn btn-outline-primary"> Отобразить все посты </a>
            <?php endif; ?>
        <?php endif; ?>

        <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header"><h2><?php echo e($post->short_title); ?></h2></div>
                    <div class="card-body">
                        <div class="card-img" style="background-image: url(<?php echo e($post->img ?? asset('img/stupa.jpg')); ?>)"></div>
                        <div class="card-author"><?php echo e($post->name); ?></div>
                        <a href="<?php echo e(route('post.show', ['id' => $post->post_id])); ?>" class="btn btn-outline-primary">Посмотреть пост</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if(!isset($_GET['search'])): ?>
        <?php echo e($posts->links()); ?>

        <?php endif; ?>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout' , ['title' => 'Главная стараница'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larelove\resources\views/posts/index.blade.php ENDPATH**/ ?>