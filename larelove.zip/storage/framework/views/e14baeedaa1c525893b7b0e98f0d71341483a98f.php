<h2>Hello Mark</h2>
<?php /**PATH C:\xampp\htdocs\larelove\resources\views/welcome.blade.php ENDPATH**/ ?>