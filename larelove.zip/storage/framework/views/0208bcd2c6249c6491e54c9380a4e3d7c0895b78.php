<?php $__env->startSection('content'); ?>
    <div class="card" >
        <h2 class="card-header">Вы зашли совсем не туда(ошибка 404)</h2>
        <img src="<?php echo e(asset('img/dove.jpg')); ?>" alt="smoke" style="height: 700px">
    </div>

    <a href="/" class="btn btn-outline-primary"> Срочно вернуться на главную </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout',['title' => " 404 ошибка.Вы попали не туда "], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larelove\resources\views/errors/404.blade.php ENDPATH**/ ?>