<?php $__env->startComponent('mail::message'); ?>
# Подтверждение электонной почты

Пожалуйста перейдите по ссылке:

<?php $__env->startComponent('mail::button', ['url' =>  route('register.verify', ['token' => $user->verify_token])]); ?>
Верефикация Email
<?php echo $__env->renderComponent(); ?>

Спасибо,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\larelove\resources\views/emails/auth/verify.blade.php ENDPATH**/ ?>