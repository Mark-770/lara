    <?php $__env->startSection('content'); ?>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><h2><?php echo e($post->title); ?></h2></div>
                    <div class="card-body">
                        <div class="card-img card-img__max" style="background-image: url(<?php echo e($post->img ?? asset('img/stupa.jpg')); ?>)"></div>
                        <div class="card-descr">Описание:<br> <?php echo e($post->descr); ?></div>
                        <div class="card-author">Автор: <?php echo e($post->name); ?></div>
                        <div class="card-date">Пост создан: <?php echo e($post->created_at->diffForHumans()); ?></div>
                        <div class="card-btn">
                            <a href="<?php echo e(route('post.index')); ?>" class="btn btn-outline-primary">На Главную</a>
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->id ==$post->author_id ): ?>
                            <a href="<?php echo e(route('post.edit', ['id'=> $post->post_id])); ?>" class="btn btn-outline-success">Редактировать</a>
                            <form action="<?php echo e(route('post.destroy',['id'=> $post->post_id])); ?> " method="post"
                                  onsubmit=" if (confirm('Точно удалить пост?')) {return true} else {return false} ">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" class="btn btn-outline-danger" value="Удалить">
                            </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout' , ['title' => "Пост №$post->post_id. $post->title"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larelove\resources\views/posts/show.blade.php ENDPATH**/ ?>