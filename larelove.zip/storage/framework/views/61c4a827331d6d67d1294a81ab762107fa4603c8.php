<h3>LaraLOve</h3>
<?php /**PATH C:\xampp\htdocs\larelove\resources\views/test.blade.php ENDPATH**/ ?>